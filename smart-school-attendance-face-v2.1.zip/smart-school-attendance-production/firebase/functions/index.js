const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');

initializeApp();
const db = getFirestore();
const SCHOOL_TZ = 'Asia/Baghdad';

function partsInBaghdad(date) {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: SCHOOL_TZ, year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', hourCycle: 'h23'
  }).formatToParts(date);
  const p = Object.fromEntries(parts.map(x => [x.type, x.value]));
  return { date: `${p.year}-${p.month}-${p.day}`, time: `${p.hour}:${p.minute}` };
}

exports.recordAttendance = onCall({ region: 'me-central1', enforceAppCheck: false }, async (request) => {
  if (!request.auth || request.auth.token.admin !== true) {
    throw new HttpsError('permission-denied', 'Administrator access is required.');
  }
  const studentId = String(request.data?.studentId || '').trim();
  if (!studentId || studentId.length > 80) {
    throw new HttpsError('invalid-argument', 'A valid student ID is required.');
  }

  const studentRef = db.collection('students').doc(studentId);
  const studentSnap = await studentRef.get();
  if (!studentSnap.exists) throw new HttpsError('not-found', 'Student was not found.');
  const student = studentSnap.data();
  const now = new Date();
  const local = partsInBaghdad(now);
  const settingsSnap = await db.collection('school_settings').doc('main').get();
  const lateAfter = settingsSnap.exists && settingsSnap.data().lateAfter
    ? settingsSnap.data().lateAfter : '08:15';
  const status = local.time > lateAfter ? 'Late' : 'Present';
  const recordId = `${local.date}_${studentId}`;
  const recordRef = db.collection('attendance').doc(recordId);

  const MIN_GAP_MS = 10 * 60 * 1000; // minimum time between arrival and departure scans
  const out = await db.runTransaction(async (tx) => {
    const snap = await tx.get(recordRef);
    if (!snap.exists) {
      tx.create(recordRef, {
        id: studentId, name: String(student.name || ''), cls: String(student.cls || ''),
        date: local.date, time: local.time, status,
        createdAt: FieldValue.serverTimestamp(), createdBy: request.auth.uid
      });
      return { kind: 'arrival', record: { id: studentId, name: String(student.name || ''), cls: String(student.cls || ''), date: local.date, time: local.time, status } };
    }
    const cur = snap.data();
    if (cur.departure) throw new HttpsError('already-exists', 'Arrival and departure are already recorded today.');
    const arrivedMs = cur.createdAt && cur.createdAt.toMillis ? cur.createdAt.toMillis() : 0;
    if (now.getTime() - arrivedMs < MIN_GAP_MS) throw new HttpsError('failed-precondition', 'Too soon after arrival. Try again later.');
    tx.update(recordRef, { departure: local.time, departureAt: FieldValue.serverTimestamp(), departureBy: request.auth.uid });
    return { kind: 'departure', record: { id: studentId, name: cur.name, cls: cur.cls, date: cur.date, time: cur.time, status: cur.status, departure: local.time } };
  });
  return out;
});
