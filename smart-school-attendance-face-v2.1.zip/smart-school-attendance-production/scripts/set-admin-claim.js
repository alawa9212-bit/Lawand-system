// Run locally after `npm install firebase-admin` and setting GOOGLE_APPLICATION_CREDENTIALS
// to a private service-account JSON file. Never upload that JSON into the website folder.
const admin = require('firebase-admin');
admin.initializeApp();
(async () => {
  const email = process.argv[2];
  if (!email) throw new Error('Usage: node scripts/set-admin-claim.js admin@example.com');
  const user = await admin.auth().getUserByEmail(email);
  await admin.auth().setCustomUserClaims(user.uid, { admin: true });
  console.log(`Admin claim set for ${email} (${user.uid}). Sign out and sign in again.`);
  process.exit(0);
})().catch(err => { console.error(err); process.exit(1); });
