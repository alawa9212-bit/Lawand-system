# Smart School Attendance 2.0 — Firebase production starter

This package continues the existing Kurdish Sorani / English, admin-only QR attendance demo. It adds a Firebase deployment scaffold, admin custom-claim setup, Firestore rules, a server-side attendance callable function (server timestamp + Asia/Baghdad school time), and a basic installable PWA shell.

## Status

Deployment starter, not a verified live service. Included in 2.1: face-recognition scanning (QR kept as a fallback), face enrollment per student, student edit/delete, arrival + departure scans, class/weekly reports with Save-as-PDF (browser print), and security fixes (no inline-JS injection from student IDs, pinned QR library, `firebase/` no longer served by Hosting). Attendance writes still need internet; only the app shell is cached.

## Face recognition: read before use

- Matching runs **in the admin's browser** with face-api.js (loaded from jsDelivr, pinned). Each student's 128-number face template is stored in `students/{id}.face` (admin-readable only). Templates are biometric data of minors: get **written guardian/school consent**, keep them only while enrolled, and use the "Remove face data" button or delete the student to erase them.
- There is **no liveness detection**: a photo of a student can fool it, and similar faces can be confused. Thresholds are strict (0.45 distance, 0.06 margin, two consecutive matches), so it may fail to recognize in poor light; use QR as fallback. Test with real classes before relying on it.
- Scan 1 = arrival (Present/Late), scan 2 (at least 10 minutes later) = departure, scan 3 is rejected.
- Reports count "school days" as days that have at least one record in the range; absent = those days minus the student's records.

## 1. Create Firebase project

1. Create a project at https://console.firebase.google.com/.
2. Add a Web App and copy its config into `firebase-config.js`.
3. Enable **Authentication → Sign-in method → Email/Password**.
4. Create the first administrator user in Authentication → Users.
5. Create Firestore Database in production mode.

## 2. Install Firebase CLI and select project

Install Node.js 20 or newer, then in this folder run:

```bash
npm install
npx firebase login
cp .firebaserc.example .firebaserc
```

Edit `.firebaserc` and replace `YOUR_PROJECT_ID` with the real Firebase project ID.

## 3. Grant the admin role

Create a private service-account key from Firebase Console → Project settings → Service accounts. Keep it outside this project folder and never upload it to hosting or share it.

On your trusted computer:

```bash
npm install firebase-admin
export GOOGLE_APPLICATION_CREDENTIALS="/absolute/path/to/service-account.json"
node scripts/set-admin-claim.js admin@example.com
```

Then sign out and sign in again in the app so the refreshed ID token contains `admin: true`.

## 4. Deploy backend and website

```bash
cd firebase/functions && npm install && cd ../..
npx firebase deploy --only firestore:rules,functions,hosting
```

If your Firebase project does not support the selected Functions region, change `region: 'me-central1'` in `firebase/functions/index.js` to a region supported by your project and close to your school.

## 5. Test before school use

- Test sign-in using the admin account; a normal account must be denied.
- Add a test student and confirm it appears on a second device.
- Scan the same QR twice on one school day; the second attempt must be rejected.
- Check that attendance documents contain `createdAt` as a Firestore server timestamp.
- Test camera permission and QR scanning on the actual iPhone Safari over HTTPS.
- Confirm Firestore rules deny unauthenticated access and direct attendance writes.
- Use fictional test records until the school approves its privacy and retention process.

## Data model

- `students/{studentId}`: `{ id, name, cls, face?, faceConsent?, faceAt? }`
- `attendance/{YYYY-MM-DD_studentId}`: `{ id, name, cls, date, time (arrival), departure?, status, createdAt, createdBy }`
- `school_settings/main`: `{ schoolName, lateAfter }`
- `admins/{uid}` is reserved for admin metadata; authorization uses the Firebase Auth custom claim `admin: true`.

## Security notes

Firebase web config is not a secret; Firestore rules and Auth custom claims are the access controls. Never put service-account JSON or Admin SDK credentials in `public` files. Use a strong unique admin password and enable App Check before public rollout. Because this system stores student information, obtain school authorization, restrict admin access, define a retention policy, and avoid collecting unnecessary personal data.
